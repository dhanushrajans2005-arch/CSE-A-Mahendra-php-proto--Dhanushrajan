<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GreenPath | Internship Portal</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>
<body>

<header class="navbar">
    <div class="container navbar-inner">
        <a href="index.php" class="logo">GreenPath.</a>

        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="#internships">Internships</a>
            <a href="#about">About</a>
            <a href="login.php">Login</a>
            <a href="register.php" class="btn">Join Now</a>
        </nav>
    </div>
</header>

<main>
    <section class="hero">
        <div class="container hero-content">
            <div>
                <p class="eyebrow">GROW • LEARN • ACHIEVE</p>

                <h1>Your Career Journey Starts Here.</h1>

                <p>
                    Discover meaningful internships, learn real-world skills,
                    and take your first step towards a successful career.
                </p>

                <a href="register.php" class="btn">Get Started →</a>
                <a href="#internships" class="btn btn-outline">
                    Explore Internships
                </a>

                <p style="margin-top:24px;font-size:14px;">
                    ✦ Learn new skills &nbsp; ✦ Meet great companies
                </p>
            </div>

            <div class="card" style="background:#e5efd8;padding:35px;">
                <p class="eyebrow">YOUR NEXT OPPORTUNITY</p>
                <h2 style="font-size:32px;font-family:Georgia,serif;">
                    Small Steps.<br>Big Futures.
                </h2>
                <p style="margin:18px 0;">
                    Find opportunities that match your interests and
                    turn your classroom knowledge into practical experience.
                </p>

                <div style="background:#fff;padding:18px;border-radius:12px;margin-top:22px;">
                    <p style="font-size:13px;">YOUR CAREER CHECKLIST</p>
                    <p>✓ Build your profile</p>
                    <p>✓ Explore opportunities</p>
                    <p>✓ Apply for internships</p>
                </div>
            </div>
        </div>
    </section>

    <section id="about">
        <div class="container">
            <p class="eyebrow">WHY GREENPATH?</p>
            <h2 class="section-title">A Better Way to Begin.</h2>
            <p class="section-subtitle">
                Everything you need to take your first career step.
            </p>

            <div class="card-grid">
                <div class="card">
                    <h3>🎓 For Students</h3>
                    <p>
                        Create your profile, discover internships,
                        and track your applications in one place.
                    </p>
                </div>

                <div class="card">
                    <h3>🏢 For Companies</h3>
                    <p>
                        Share internship opportunities and connect
                        with talented students.
                    </p>
                </div>

                <div class="card">
                    <h3>🌱 Grow Your Skills</h3>
                    <p>
                        Explore opportunities that help you gain
                        experience and prepare for your future.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section id="internships" style="background:#edf2e6;">
        <div class="container">
            <p class="eyebrow">EXPLORE OPPORTUNITIES</p>
            <h2 class="section-title">Find Your Starting Point.</h2>
            <p class="section-subtitle">
                Here are a few examples of internship fields you can explore.
                These are sample listings, not live database results.
            </p>

            <div class="card-grid">
                <div class="card">
                    <span class="badge">Technology</span>
                    <h3 style="margin-top:16px;">Web Development Intern</h3>
                    <p>Build websites and practise front-end and back-end skills.</p>
                    <p style="margin:15px 0;">Skills: HTML, CSS, PHP</p>
                    <a href="login.php" class="btn">Explore More →</a>
                </div>

                <div class="card">
                    <span class="badge">Creative</span>
                    <h3 style="margin-top:16px;">UI/UX Design Intern</h3>
                    <p>Learn to create clear, useful, and user-friendly designs.</p>
                    <p style="margin:15px 0;">Skills: Design, Prototyping</p>
                    <a href="login.php" class="btn">Explore More →</a>
                </div>

                <div class="card">
                    <span class="badge">Analytics</span>
                    <h3 style="margin-top:16px;">Data Analyst Intern</h3>
                    <p>Practise working with data and communicating insights.</p>
                    <p style="margin:15px 0;">Skills: Excel, SQL, Python</p>
                    <a href="login.php" class="btn">Explore More →</a>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container card" style="text-align:center;padding:45px 25px;">
            <p class="eyebrow">YOUR FUTURE IS WAITING</p>
            <h2 class="section-title">Ready to Take the First Step?</h2>
            <p class="section-subtitle">
                Create your account and begin exploring career opportunities.
            </p>
            <a href="register.php" class="btn">Create Your Account →</a>
        </div>
    </section>
</main>

<footer class="footer">
    <div class="container">
        <h3 style="color:#fff;">GreenPath.</h3>
        <p>Helping students grow through meaningful internship opportunities.</p>
        <p style="margin-top:12px;">© <?php echo date("Y"); ?> GreenPath Internship Portal</p>
    </div>
</footer>

</body>
</html>