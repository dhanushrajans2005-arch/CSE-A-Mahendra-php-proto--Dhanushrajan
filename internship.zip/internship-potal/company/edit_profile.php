<?php
session_start();

if (!isset($_SESSION["company_logged_in"])) {
    header("Location: ../login.php");
    exit;
}

if (!isset($_SESSION["company_profile"])) {
    $_SESSION["company_profile"] = [
        "name" => $_SESSION["company_name"] ?? "GreenTech Solutions",
        "email" => "hr@greentech.example",
        "phone" => "",
        "website" => "",
        "location" => "",
        "industry" => "",
        "description" => "",
        "size" => ""
    ];
}

$profile = $_SESSION["company_profile"];
$message = "";
$error = "";

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    $website = trim($_POST["website"] ?? "");
    $location = trim($_POST["location"] ?? "");
    $industry = trim($_POST["industry"] ?? "");
    $description = trim($_POST["description"] ?? "");
    $size = trim($_POST["size"] ?? "");

    if ($name === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a company name and a valid email.";
    } elseif (
        $website !== "" &&
        !filter_var($website, FILTER_VALIDATE_URL)
    ) {
        $error = "Please enter a valid website URL, including https://";
    } else {
        $_SESSION["company_profile"] = [
            "name" => $name,
            "email" => $email,
            "phone" => $phone,
            "website" => $website,
            "location" => $location,
            "industry" => $industry,
            "description" => $description,
            "size" => $size
        ];

        $_SESSION["company_name"] = $name;
        $profile = $_SESSION["company_profile"];
        $message = "Company profile updated successfully!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Company Profile | Internship Portal</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a href="dashboard.php" class="logo">GreenPath Careers</a>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">My Profile</a>
            <a href="internships.php">My Internships</a>
            <a href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="container">
    <div class="form-container">
        <p class="eyebrow">Company Settings</p>
        <h2>Edit Company Profile</h2>

        <?php if ($message !== ""): ?>
            <div class="alert alert-success">
                <?= e($message) ?>
            </div>
            <p style="text-align:center; margin-bottom:18px;">
                <a href="profile.php">View Company Profile →</a>
            </p>
        <?php endif; ?>

        <?php if ($error !== ""): ?>
            <div class="alert alert-error">
                <?= e($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="name">Company Name *</label>
                <input type="text" id="name" name="name"
                    value="<?= e($profile["name"]) ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Company Email *</label>
                <input type="email" id="email" name="email"
                    value="<?= e($profile["email"]) ?>" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone"
                    value="<?= e($profile["phone"]) ?>">
            </div>

            <div class="form-group">
                <label for="website">Company Website</label>
                <input type="url" id="website" name="website"
                    placeholder="https://example.com"
                    value="<?= e($profile["website"]) ?>">
            </div>

            <div class="form-group">
                <label for="location">Company Location</label>
                <input type="text" id="location" name="location"
                    value="<?= e($profile["location"]) ?>">
            </div>

            <div class="form-group">
                <label for="industry">Industry</label>
                <input type="text" id="industry" name="industry"
                    placeholder="e.g. Information Technology"
                    value="<?= e($profile["industry"]) ?>">
            </div>

            <div class="form-group">
                <label for="size">Company Size</label>
                <select id="size" name="size">
                    <option value="">Select company size</option>
                    <?php
                    $sizes = [
                        "1-10 Employees",
                        "11-50 Employees",
                        "51-200 Employees",
                        "201-500 Employees",
                        "500+ Employees"
                    ];
                    foreach ($sizes as $item):
                    ?>
                        <option value="<?= e($item) ?>"
                            <?= $profile["size"] === $item ? "selected" : "" ?>>
                            <?= e($item) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="description">About Company</label>
                <textarea id="description" name="description"
                    placeholder="Tell students about your company..."><?= e($profile["description"]) ?></textarea>
            </div>

            <button type="submit" style="width:100%;">
                Save Changes
            </button>
        </form>

        <p style="text-align:center; margin-top:20px;">
            <a href="profile.php">← Back to Company Profile</a>
        </p>
    </div>
</main>

<footer class="footer">
    <div class="container">
        <p>© 2026 GreenPath Careers</p>
        <p>Growing careers, naturally.</p>
    </div>
</footer>

</body>
</html>