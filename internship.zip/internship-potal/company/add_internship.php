<?php
session_start();



if (!isset($_SESSION["company_internships"])) {
    $_SESSION["company_internships"] = [];
}

$success = "";
$error = "";

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"] ?? "");
    $category = trim($_POST["category"] ?? "");
    $location = trim($_POST["location"] ?? "");
    $workType = trim($_POST["work_type"] ?? "");
    $duration = trim($_POST["duration"] ?? "");
    $stipend = trim($_POST["stipend"] ?? "");
    $skills = trim($_POST["skills"] ?? "");
    $description = trim($_POST["description"] ?? "");
    $deadline = trim($_POST["deadline"] ?? "");

    if (
        $title === "" ||
        $category === "" ||
        $location === "" ||
        $workType === "" ||
        $duration === "" ||
        $stipend === "" ||
        $skills === "" ||
        $description === "" ||
        $deadline === ""
    ) {
        $error = "Please fill in all fields.";
    } elseif ($deadline < date("Y-m-d")) {
        $error = "Application deadline cannot be in the past.";
    } else {
        $newInternship = [
            "id" => uniqid("internship_"),
            "title" => $title,
            "category" => $category,
            "location" => $location,
            "work_type" => $workType,
            "duration" => $duration,
            "stipend" => $stipend,
            "skills" => $skills,
            "description" => $description,
            "deadline" => $deadline,
            "status" => "Active"
        ];

        $_SESSION["company_internships"][] = $newInternship;

        $success = "Internship added successfully!";
        $_POST = [];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Internship | GreenPath</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a class="logo" href="/proxy/9010/index.php">GreenPath</a>

        <div class="nav-links">
            <a href="/proxy/9010/company/dashboard.php">Dashboard</a>
            <a href="/proxy/9010/company/profile.php">Company Profile</a>
            <a href="/proxy/9010/company/internships.php">My Internships</a>
            <a href="/proxy/9010/company/add_internship.php">Add Internship</a>
            <a href="/proxy/9010/company/applicants.php">Applicants</a>
            <a href="/proxy/9010/logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="container">

    <div class="form-container" style="max-width:720px;">
        <p class="eyebrow">Create an opportunity</p>
        <h2>Add New Internship</h2>

        <p style="text-align:center; margin-bottom:24px; color:#68786d;">
            Share a new opportunity with talented students.
        </p>

        <?php if ($success !== ""): ?>
            <div class="alert alert-success">
                <?= e($success) ?>
                <p style="margin-top:8px;">
                    This demo posting is saved in your session only.
                </p>
            </div>

            <a class="btn"
               href="/proxy/9010/company/internships.php">
                View My Internships
            </a>

        <?php endif; ?>

        <?php if ($error !== ""): ?>
            <div class="alert alert-error">
                <?= e($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="add_internship.php">

            <div class="form-group">
                <label for="title">Internship Title *</label>
                <input
                    type="text"
                    id="title"
                    name="title"
                    placeholder="e.g. PHP Developer Intern"
                    value="<?= e($_POST["title"] ?? "") ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="category">Category *</label>
                <select id="category" name="category" required>
                    <option value="">Choose category</option>
                    <?php
                    $categories = [
                        "Web Development",
                        "Software Development",
                        "UI/UX Design",
                        "Data Analytics",
                        "Digital Marketing",
                        "Cybersecurity",
                        "Other"
                    ];

                    foreach ($categories as $item):
                    ?>
                        <option
                            value="<?= e($item) ?>"
                            <?= ($_POST["category"] ?? "") === $item
                                ? "selected" : "" ?>
                        >
                            <?= e($item) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="location">Location *</label>
                <input
                    type="text"
                    id="location"
                    name="location"
                    placeholder="e.g. Chennai or Remote"
                    value="<?= e($_POST["location"] ?? "") ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="work_type">Work Type *</label>
                <select id="work_type" name="work_type" required>
                    <option value="">Choose work type</option>
                    <?php
                    $workTypes = ["On-site", "Remote", "Hybrid"];

                    foreach ($workTypes as $item):
                    ?>
                        <option
                            value="<?= e($item) ?>"
                            <?= ($_POST["work_type"] ?? "") === $item
                                ? "selected" : "" ?>
                        >
                            <?= e($item) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="duration">Duration *</label>
                <input
                    type="text"
                    id="duration"
                    name="duration"
                    placeholder="e.g. 3 Months"
                    value="<?= e($_POST["duration"] ?? "") ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="stipend">Stipend *</label>
                <input
                    type="text"
                    id="stipend"
                    name="stipend"
                    placeholder="e.g. ₹8,000 per month or Unpaid"
                    value="<?= e($_POST["stipend"] ?? "") ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="skills">Required Skills *</label>
                <input
                    type="text"
                    id="skills"
                    name="skills"
                    placeholder="e.g. HTML, CSS, PHP, MySQL"
                    value="<?= e($_POST["skills"] ?? "") ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="description">Internship Description *</label>
                <textarea
                    id="description"
                    name="description"
                    placeholder="Explain the role, responsibilities and requirements..."
                    required><?= e($_POST["description"] ?? "") ?></textarea>
            </div>

            <div class="form-group">
                <label for="deadline">Application Deadline *</label>
                <input
                    type="date"
                    id="deadline"
                    name="deadline"
                    min="<?= date("Y-m-d") ?>"
                    value="<?= e($_POST["deadline"] ?? "") ?>"
                    required
                >
            </div>

            <button type="submit" style="width:100%;">
                Publish Internship
            </button>
        </form>

        <p style="text-align:center; margin-top:18px;">
            <a href="/proxy/9010/company/dashboard.php">
                Back to Dashboard
            </a>
        </p>
    </div>

</main>

<footer class="footer">
    <div class="container">
        <p><strong>GreenPath — Internship Portal</strong></p>
        <p>Connecting companies with future talent.</p>
    </div>
</footer>

</body>
</html>