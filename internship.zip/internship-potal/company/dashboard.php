<?php
session_start();



$companyName = $_SESSION["company_name"] ?? "GreenTech Solutions";

$totalInternships = 6;
$totalApplicants = 24;
$pendingApplications = 8;
$shortlistedApplicants = 10;

$recentInternships = [
    [
        "title" => "Web Development Intern",
        "type" => "Full Time",
        "applicants" => 12,
        "status" => "Active"
    ],
    [
        "title" => "PHP Developer Intern",
        "type" => "Hybrid",
        "applicants" => 7,
        "status" => "Active"
    ],
    [
        "title" => "UI/UX Design Intern",
        "type" => "Remote",
        "applicants" => 5,
        "status" => "Active"
    ]
];

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Dashboard | GreenPath</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">

    <style>
        .dashboard-heading {
            padding: 38px 0 15px;
        }

        .dashboard-heading p {
            color: #68786d;
        }

        .quick-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin: 25px 0;
        }

        .dashboard-panel {
            background: #fff;
            border: 1px solid #dce6d5;
            border-radius: 15px;
            padding: 25px;
            margin-top: 25px;
            box-shadow: 0 8px 25px rgba(23,61,43,.06);
        }

        .company-welcome {
            background: linear-gradient(120deg, #e5efd8, #f7f6ed);
            padding: 30px;
            border-radius: 16px;
            margin-top: 20px;
        }

        .company-welcome h2 {
            font-family: Georgia, serif;
            font-size: 30px;
        }

        .status.active {
            background: #d9f0d7;
            color: #205b32;
        }

        @media(max-width:600px) {
            .company-welcome h2 {
                font-size: 24px;
            }

            .dashboard-panel {
                padding: 16px;
            }
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a class="logo" href="/proxy/9010/index.php">GreenPath</a>

        <div class="nav-links">
            <a href="/proxy/9010/company/dashboard.php">Dashboard</a>
            <a href="/proxy/9010/company/profile.php">Company Profile</a>
            <a href="/proxy/9010/company/internships.php">My Internships</a>
            <a href="/proxy/9010/company/add_internship.php">Add Internship</a>
            <a href="/proxy/9010/company/applicants.php">Applicants</a>
            <a href="/proxy/9010/logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="container">

    <div class="dashboard-heading">
        <p class="eyebrow">Company Workspace</p>
        <h1 class="section-title">Company Dashboard</h1>
        <p>Manage your internship opportunities and applicants.</p>
    </div>

    <div class="company-welcome">
        <p class="eyebrow">Welcome Back</p>
        <h2><?= e($companyName) ?></h2>
        <p>
            Find talented students and help them grow through meaningful
            internship opportunities.
        </p>

        <div class="quick-actions">
            <a class="btn"
               href="/proxy/9010/company/add_internship.php">
                + Add Internship
            </a>

            <a class="btn btn-outline"
               href="/proxy/9010/company/applicants.php">
                View Applicants
            </a>

            <a class="btn btn-outline"
               href="/proxy/9010/company/profile.php">
                Edit Company Profile
            </a>
        </div>
    </div>

    <section>
        <h2 class="section-title">Overview</h2>
        <p class="section-subtitle">
            A quick look at your internship activity.
        </p>

        <div class="stats-grid">
            <div class="stat-card">
                <p>Total Internships</p>
                <div class="stat-number">
                    <?= $totalInternships ?>
                </div>
            </div>

            <div class="stat-card">
                <p>Total Applicants</p>
                <div class="stat-number">
                    <?= $totalApplicants ?>
                </div>
            </div>

            <div class="stat-card">
                <p>Pending Applications</p>
                <div class="stat-number">
                    <?= $pendingApplications ?>
                </div>
            </div>

            <div class="stat-card">
                <p>Shortlisted</p>
                <div class="stat-number">
                    <?= $shortlistedApplicants ?>
                </div>
            </div>
        </div>
    </section>

    <div class="dashboard-panel">
        <h2>Recent Internships</h2>
        <p class="section-subtitle">
            View the latest opportunities listed by your company.
        </p>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Internship Title</th>
                        <th>Work Type</th>
                        <th>Applicants</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($recentInternships as $internship): ?>
                        <tr>
                            <td><?= e($internship["title"]) ?></td>
                            <td><?= e($internship["type"]) ?></td>
                            <td><?= (int)$internship["applicants"] ?></td>
                            <td>
                                <span class="status active">
                                    <?= e($internship["status"]) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <a class="btn"
           href="/proxy/9010/company/internships.php">
            View All Internships
        </a>
    </div>

    <div class="dashboard-panel">
        <h2>Quick Links</h2>

        <div class="card-grid" style="margin-top:20px;">
            <div class="card">
                <h3>Add Internship</h3>
                <p>Create a new internship opportunity for students.</p>
                <br>
                <a class="btn"
                   href="/proxy/9010/company/add_internship.php">
                    Create
                </a>
            </div>

            <div class="card">
                <h3>Manage Applicants</h3>
                <p>Review applications and check student details.</p>
                <br>
                <a class="btn"
                   href="/proxy/9010/company/applicants.php">
                    Manage
                </a>
            </div>

            <div class="card">
                <h3>Company Profile</h3>
                <p>View and update your company information.</p>
                <br>
                <a class="btn"
                   href="/proxy/9010/company/profile.php">
                    View Profile
                </a>
            </div>
        </div>
    </div>

</main>

<footer class="footer">
    <div class="container">
        <p><strong>GreenPath — Internship Portal</strong></p>
        <p>Connecting companies with future talent.</p>
    </div>
</footer>

</body>
</html>