<?php
session_start();

/*
  Demo internship list.
  add_internship.php-la session-la save panna internships-um
  indha page-la display aagum.
*/

$sampleInternships = [
    [
        "id" => "demo1",
        "title" => "Web Development Intern",
        "category" => "Web Development",
        "location" => "Chennai",
        "work_type" => "Hybrid",
        "duration" => "3 Months",
        "stipend" => "₹8,000 / month",
        "skills" => "HTML, CSS, PHP",
        "deadline" => "2026-11-30",
        "status" => "Active"
    ],
    [
        "id" => "demo2",
        "title" => "PHP Developer Intern",
        "category" => "Software Development",
        "location" => "Remote",
        "work_type" => "Remote",
        "duration" => "2 Months",
        "stipend" => "₹6,000 / month",
        "skills" => "PHP, MySQL",
        "deadline" => "2026-12-15",
        "status" => "Active"
    ],
    [
        "id" => "demo3",
        "title" => "UI/UX Design Intern",
        "category" => "UI/UX Design",
        "location" => "Coimbatore",
        "work_type" => "On-site",
        "duration" => "3 Months",
        "stipend" => "₹7,000 / month",
        "skills" => "Figma, Wireframing",
        "deadline" => "2026-12-20",
        "status" => "Active"
    ]
];

$addedInternships = $_SESSION["company_internships"] ?? [];

$internships = array_merge(
    array_reverse($addedInternships),
    $sampleInternships
);

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Internships | GreenPath</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">

    <style>
        .page-heading {
            padding: 38px 0 10px;
        }

        .internship-card {
            background: #fff;
            border: 1px solid #dce6d5;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 8px 25px rgba(23,61,43,.06);
        }

        .internship-card h3 {
            margin-bottom: 8px;
        }

        .internship-card p {
            margin: 7px 0;
            color: #68786d;
            overflow-wrap: anywhere;
        }

        .internship-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 15px;
        }

        .internship-meta {
            background: #f7f6ed;
            border-radius: 10px;
            padding: 12px;
            margin: 15px 0;
        }

        .internship-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 18px;
        }

        .empty-state {
            padding: 35px;
            text-align: center;
            border: 1px dashed #a8c686;
            border-radius: 15px;
            background: #fff;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a class="logo" href="/proxy/9010/index.php">GreenPath</a>

        <div class="nav-links">
            <a href="/proxy/9010/company/dashboard.php">Dashboard</a>
            <a href="/proxy/9010/company/profile.php">Company Profile</a>
            <a href="/proxy/9010/company/internships.php">My Internships</a>
            <a href="/proxy/9010/company/add_internship.php">Add Internship</a>
            <a href="/proxy/9010/company/applicants.php">Applicants</a>
            <a href="/proxy/9010/logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="container">

    <div class="page-heading">
        <p class="eyebrow">Manage opportunities</p>
        <h1 class="section-title">My Internships</h1>
        <p class="section-subtitle">
            View the internship opportunities listed by your company.
        </p>

        <a class="btn"
           href="/proxy/9010/company/add_internship.php">
            + Add New Internship
        </a>
    </div>

    <section style="padding-top:20px;">

        <div class="stats-grid" style="margin-bottom:30px;">
            <div class="stat-card">
                <p>Total Internships</p>
                <div class="stat-number">
                    <?= count($internships) ?>
                </div>
            </div>

            <div class="stat-card">
                <p>Active Internships</p>
                <div class="stat-number">
                    <?php
                    echo count(array_filter($internships, function($item) {
                        return $item["status"] === "Active";
                    }));
                    ?>
                </div>
            </div>
        </div>

        <?php if (empty($internships)): ?>

            <div class="empty-state">
                <h3>No Internships Yet</h3>
                <p>Create your first internship opportunity.</p>
                <br>
                <a class="btn"
                   href="/proxy/9010/company/add_internship.php">
                    Add Internship
                </a>
            </div>

        <?php else: ?>

            <div class="card-grid">

                <?php foreach ($internships as $internship): ?>

                    <article class="internship-card">

                        <div class="internship-top">
                            <span class="badge">
                                <?= e($internship["category"]) ?>
                            </span>

                            <span class="status active">
                                <?= e($internship["status"]) ?>
                            </span>
                        </div>

                        <h3><?= e($internship["title"]) ?></h3>

                        <p>
                            <strong>Location:</strong>
                            <?= e($internship["location"]) ?>
                        </p>

                        <p>
                            <strong>Work Type:</strong>
                            <?= e($internship["work_type"]) ?>
                        </p>

                        <div class="internship-meta">
                            <p>
                                <strong>Duration:</strong>
                                <?= e($internship["duration"]) ?>
                            </p>

                            <p>
                                <strong>Stipend:</strong>
                                <?= e($internship["stipend"]) ?>
                            </p>

                            <p>
                                <strong>Skills:</strong>
                                <?= e($internship["skills"]) ?>
                            </p>

                            <p>
                                <strong>Deadline:</strong>
                                <?= e($internship["deadline"]) ?>
                            </p>
                        </div>

                        <div class="internship-actions">
                            <a class="btn"
                               href="/proxy/9010/company/applicants.php">
                                View Applicants
                            </a>
                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </section>
</main>

<footer class="footer">
    <div class="container">
        <p><strong>GreenPath — Internship Portal</strong></p>
        <p>Connecting companies with future talent.</p>
    </div>
</footer>

</body>
</html>