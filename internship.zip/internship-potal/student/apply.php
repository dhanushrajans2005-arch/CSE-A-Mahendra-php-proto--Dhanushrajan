<?php
session_start();

$internships = [
    1 => [
        "title" => "Web Development Intern",
        "company" => "GreenTech Solutions",
        "duration" => "3 Months",
        "stipend" => "₹8,000 / month"
    ],
    2 => [
        "title" => "PHP Developer Intern",
        "company" => "CodeLeaf Technologies",
        "duration" => "2 Months",
        "stipend" => "₹6,000 / month"
    ],
    3 => [
        "title" => "UI/UX Design Intern",
        "company" => "CreativeNest",
        "duration" => "3 Months",
        "stipend" => "₹7,000 / month"
    ],
    4 => [
        "title" => "Python Developer Intern",
        "company" => "EcoByte Systems",
        "duration" => "3 Months",
        "stipend" => "₹10,000 / month"
    ],
    5 => [
        "title" => "Data Analyst Intern",
        "company" => "Nature Analytics",
        "duration" => "2 Months",
        "stipend" => "₹8,000 / month"
    ],
    6 => [
        "title" => "Digital Marketing Intern",
        "company" => "Bloom Media",
        "duration" => "2 Months",
        "stipend" => "₹5,000 / month"
    ]
];

$jobId = isset($_GET["job"]) ? (int) $_GET["job"] : 1;
$job = $internships[$jobId] ?? null;

$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    $college = trim($_POST["college"] ?? "");
    $coverLetter = trim($_POST["cover_letter"] ?? "");

    if (!$job) {
        $error = "Internship not found. Please choose an available internship.";
    } elseif (
        $name === "" ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        $phone === "" ||
        $college === "" ||
        $coverLetter === ""
    ) {
        $error = "Please fill in all fields with valid information.";
    } else {
        $success = "Your application form is complete! Database connection will be added later, so this demo application is not saved permanently.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Internship | GreenPath</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a class="logo" href="/proxy/9010/index.php">GreenPath</a>

        <div class="nav-links">
            <a href="/proxy/9010/student/dashboard.php">Dashboard</a>
            <a href="/proxy/9010/student/internships.php">Internships</a>
            <a href="/proxy/9010/student/applications.php">My Applications</a>
            <a href="/proxy/9010/student/profile.php">My Profile</a>
            <a href="/proxy/9010/logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="container">
    <div class="form-container">

        <p class="eyebrow">Take the next step</p>
        <h2>Apply for Internship</h2>

        <?php if ($success !== ""): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($success) ?>
            </div>

            <a class="btn" href="/proxy/9010/student/internships.php">
                Browse More Internships
            </a>

            <a class="btn btn-outline"
               href="/proxy/9010/student/dashboard.php">
                Dashboard
            </a>

        <?php else: ?>

            <?php if ($error !== ""): ?>
                <div class="alert alert-error">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <?php if ($job): ?>
                <div class="card" style="margin-bottom:24px;">
                    <h3><?= htmlspecialchars($job["title"]) ?></h3>
                    <p>
                        <strong>Company:</strong>
                        <?= htmlspecialchars($job["company"]) ?>
                    </p>
                    <p>
                        <strong>Duration:</strong>
                        <?= htmlspecialchars($job["duration"]) ?>
                    </p>
                    <p>
                        <strong>Stipend:</strong>
                        <?= htmlspecialchars($job["stipend"]) ?>
                    </p>
                </div>

                <form method="POST"
                      action="apply.php?job=<?= (int) $jobId ?>">

                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            placeholder="Enter your full name"
                            value="<?= htmlspecialchars($_POST["name"] ?? "") ?>"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="Enter your email"
                            value="<?= htmlspecialchars($_POST["email"] ?? "") ?>"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input
                            type="tel"
                            id="phone"
                            name="phone"
                            placeholder="Enter your phone number"
                            value="<?= htmlspecialchars($_POST["phone"] ?? "") ?>"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="college">College Name</label>
                        <input
                            type="text"
                            id="college"
                            name="college"
                            placeholder="Enter your college name"
                            value="<?= htmlspecialchars($_POST["college"] ?? "") ?>"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="cover_letter">
                            Why are you suitable for this internship?
                        </label>
                        <textarea
                            id="cover_letter"
                            name="cover_letter"
                            placeholder="Tell the company about your skills and interests..."
                            required><?= htmlspecialchars($_POST["cover_letter"] ?? "") ?></textarea>
                    </div>

                    <button type="submit" style="width:100%;">
                        Submit Application
                    </button>
                </form>

            <?php else: ?>
                <div class="alert alert-error">
                    Internship not found. Please select an internship first.
                </div>

                <a class="btn"
                   href="/proxy/9010/student/internships.php">
                    View Internships
                </a>
            <?php endif; ?>

        <?php endif; ?>

    </div>
</main>

<footer class="footer">
    <div class="container">
        <p><strong>GreenPath — Internship Portal</strong></p>
        <p>Discover opportunities. Grow your future.</p>
    </div>
</footer>

</body>
</html>