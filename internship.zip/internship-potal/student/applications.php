<?php
session_start();



$applications = [
    [
        "title" => "Web Development Intern",
        "company" => "GreenTech Solutions",
        "applied_date" => "2026-10-01",
        "status" => "Pending"
    ],
    [
        "title" => "UI/UX Design Intern",
        "company" => "CreativeNest",
        "applied_date" => "2026-10-03",
        "status" => "Under Review"
    ],
    [
        "title" => "Python Developer Intern",
        "company" => "EcoByte Systems",
        "applied_date" => "2026-10-05",
        "status" => "Accepted"
    ]
];

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications | GreenPath</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">

    <style>
        .page-heading {
            padding: 38px 0 10px;
        }

        .application-card {
            background: #fff;
            border: 1px solid #dce6d5;
            border-radius: 14px;
            padding: 22px;
            margin-bottom: 18px;
            box-shadow: 0 8px 25px rgba(23,61,43,.06);
        }

        .application-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 12px;
        }

        .application-card p {
            color: #68786d;
            margin-top: 5px;
        }

        .status.accepted {
            background: #d9f0d7;
            color: #205b32;
        }

        .status.under-review {
            background: #f8efcf;
            color: #765d1b;
        }

        .empty-state {
            background: #fff;
            border: 1px dashed #a8c686;
            border-radius: 14px;
            padding: 35px;
            text-align: center;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a class="logo" href="/proxy/9010/index.php">GreenPath</a>

        <div class="nav-links">
            <a href="/proxy/9010/student/dashboard.php">Dashboard</a>
            <a href="/proxy/9010/student/internships.php">Internships</a>
            <a href="/proxy/9010/student/applications.php">My Applications</a>
            <a href="/proxy/9010/student/profile.php">My Profile</a>
            <a href="/proxy/9010/logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="container">

    <div class="page-heading">
        <p class="eyebrow">Track your progress</p>
        <h1 class="section-title">My Applications</h1>
        <p class="section-subtitle">
            View the internships you have applied for and check their status.
        </p>
    </div>

    <section style="padding-top:15px;">

        <div class="stats-grid" style="margin-bottom:30px;">
            <div class="stat-card">
                <p>Total Applications</p>
                <div class="stat-number">
                    <?= count($applications) ?>
                </div>
            </div>

            <div class="stat-card">
                <p>Pending</p>
                <div class="stat-number">
                    <?php
                    echo count(array_filter($applications, function($app) {
                        return $app["status"] === "Pending";
                    }));
                    ?>
                </div>
            </div>

            <div class="stat-card">
                <p>Under Review</p>
                <div class="stat-number">
                    <?php
                    echo count(array_filter($applications, function($app) {
                        return $app["status"] === "Under Review";
                    }));
                    ?>
                </div>
            </div>

            <div class="stat-card">
                <p>Accepted</p>
                <div class="stat-number">
                    <?php
                    echo count(array_filter($applications, function($app) {
                        return $app["status"] === "Accepted";
                    }));
                    ?>
                </div>
            </div>
        </div>

        <?php if (empty($applications)): ?>

            <div class="empty-state">
                <h3>No Applications Yet</h3>
                <p>You have not applied for any internships yet.</p>

                <br>

                <a class="btn"
                   href="/proxy/9010/student/internships.php">
                    Explore Internships
                </a>
            </div>

        <?php else: ?>

            <?php foreach ($applications as $app): ?>

                <?php
                $statusClass = strtolower(
                    str_replace(" ", "-", $app["status"])
                );
                ?>

                <article class="application-card">
                    <div class="application-top">
                        <div>
                            <h3><?= e($app["title"]) ?></h3>
                            <p>
                                <strong>Company:</strong>
                                <?= e($app["company"]) ?>
                            </p>
                            <p>
                                <strong>Applied Date:</strong>
                                <?= e($app["applied_date"]) ?>
                            </p>
                        </div>

                        <span class="status <?= e($statusClass) ?>">
                            <?= e($app["status"]) ?>
                        </span>
                    </div>
                </article>

            <?php endforeach; ?>

        <?php endif; ?>

        <div style="margin-top:25px;">
            <a class="btn"
               href="/proxy/9010/student/internships.php">
                Browse More Internships
            </a>

            <a class="btn btn-outline"
               href="/proxy/9010/student/dashboard.php">
                Back to Dashboard
            </a>
        </div>

    </section>
</main>

<footer class="footer">
    <div class="container">
        <p><strong>GreenPath — Internship Portal</strong></p>
        <p>Discover opportunities. Grow your future.</p>
    </div>
</footer>

</body>
</html>