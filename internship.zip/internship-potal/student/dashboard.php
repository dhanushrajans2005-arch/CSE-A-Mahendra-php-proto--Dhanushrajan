<?php
session_start();

$studentName = $_SESSION["student_name"] ?? "Student";

$internships = [
    [
        "title" => "Web Development Intern",
        "company" => "GreenTech Solutions",
        "location" => "Remote",
        "duration" => "3 Months",
        "stipend" => "₹8,000/month",
        "skills" => "HTML, CSS, PHP"
    ],
    [
        "title" => "UI/UX Design Intern",
        "company" => "Creative Nest",
        "location" => "Hybrid",
        "duration" => "2 Months",
        "stipend" => "₹6,000/month",
        "skills" => "Figma, UI Design"
    ],
    [
        "title" => "Data Analyst Intern",
        "company" => "Insight Labs",
        "location" => "Chennai",
        "duration" => "3 Months",
        "stipend" => "₹10,000/month",
        "skills" => "Python, SQL, Excel"
    ]
];

$totalInternships = 12;
$totalApplications = 3;
$underReview = 1;
$shortlisted = 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Dashboard | GreenPath</title>

    <link rel="stylesheet" href="/proxy/9010/css/style.css">

    <style>
        .student-hero {
            padding: 50px 0;
            background: linear-gradient(120deg, #e5efd8, #f7f6ed);
        }

        .hero-flex {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            flex-wrap: wrap;
        }

        .welcome-tag {
            display: inline-block;
            background: #dce9cd;
            color: #24543b;
            padding: 6px 13px;
            border-radius: 25px;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 12px;
        }

        .student-hero h1 {
            font-family: Georgia, serif;
            font-size: clamp(30px, 4vw, 44px);
            color: #173d2b;
            margin-bottom: 12px;
        }

        .student-hero p {
            color: #68786d;
        }

        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 20px;
        }

        .stat-box {
            background: white;
            padding: 24px;
            border: 1px solid #dce6d5;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(23,61,43,.06);
        }

        .stat-box p {
            color: #68786d;
            font-size: 14px;
        }

        .stat-box h2 {
            font-size: 32px;
            margin-top: 8px;
        }

        .quick-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
        }

        .quick-card {
            display: block;
            background: white;
            border: 1px solid #dce6d5;
            padding: 24px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(23,61,43,.05);
            transition: .2s;
        }

        .quick-card:hover {
            background: #e5efd8;
            transform: translateY(-4px);
        }

        .quick-card p {
            color: #68786d;
            font-size: 14px;
        }

        .internship-card {
            background: white;
            border: 1px solid #dce6d5;
            padding: 23px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(23,61,43,.05);
        }

        .internship-card p {
            color: #68786d;
            margin: 7px 0;
        }

        .tag {
            display: inline-block;
            background: #e5efd8;
            color: #24543b;
            border-radius: 20px;
            padding: 5px 10px;
            font-size: 12px;
            font-weight: 600;
        }

        @media(max-width: 850px) {
            .dashboard-stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .quick-grid {
                grid-template-columns: 1fr;
            }

            .card-grid {
                grid-template-columns: 1fr;
            }
        }

        @media(max-width: 500px) {
            .dashboard-stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<nav class="navbar">
    <div class="container navbar-inner">

        <a href="../index.php" class="logo">GreenPath.</a>

        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="internships.php">Internships</a>
            <a href="applications.php">My Applications</a>
            <a href="profile.php">My Profile</a>
            <a href="../logout.php">Logout</a>
        </div>

    </div>
</nav>

<header class="student-hero">
    <div class="container hero-flex">

        <div>
            <span class="welcome-tag">STUDENT DASHBOARD</span>

            <h1>
                Welcome back,
                <?php echo htmlspecialchars($studentName); ?>!
            </h1>

            <p>
                Your next opportunity could be one application away.
            </p>
        </div>

        <a href="internships.php" class="btn">
            Explore Internships →
        </a>

    </div>
</header>

<main>

    <section>
        <div class="container">

            <h2 class="section-title">Your Progress</h2>

            <p class="section-subtitle">
                Keep track of your internship journey.
            </p>

            <div class="dashboard-stats">

                <div class="stat-box">
                    <p>Available Internships</p>
                    <h2><?php echo $totalInternships; ?></h2>
                </div>

                <div class="stat-box">
                    <p>My Applications</p>
                    <h2><?php echo $totalApplications; ?></h2>
                </div>

                <div class="stat-box">
                    <p>Under Review</p>
                    <h2><?php echo $underReview; ?></h2>
                </div>

                <div class="stat-box">
                    <p>Shortlisted</p>
                    <h2><?php echo $shortlisted; ?></h2>
                </div>

            </div>

        </div>
    </section>

    <section style="background:#f0f4e9;">
        <div class="container">

            <h2 class="section-title">Quick Access</h2>

            <p class="section-subtitle">
                Everything you need, all in one place.
            </p>

            <div class="quick-grid">

                <a href="internships.php" class="quick-card">
                    <h3>Explore Internships →</h3>
                    <p>
                        Discover opportunities and find the right role for you.
                    </p>
                </a>

                <a href="applications.php" class="quick-card">
                    <h3>Track Applications →</h3>
                    <p>
                        Check the status of your submitted applications.
                    </p>
                </a>

                <a href="profile.php" class="quick-card">
                    <h3>Update My Profile →</h3>
                    <p>
                        Keep your skills and academic details updated.
                    </p>
                </a>

            </div>

        </div>
    </section>

    <section>
        <div class="container">

            <h2 class="section-title">Recommended Internships</h2>

            <p class="section-subtitle">
                Explore these sample opportunities to get started.
            </p>

            <div class="card-grid">

                <?php foreach ($internships as $internship): ?>

                    <article class="internship-card">

                        <span class="tag">
                            <?php echo htmlspecialchars($internship["location"]); ?>
                        </span>

                        <h3 style="margin-top:12px;">
                            <?php echo htmlspecialchars($internship["title"]); ?>
                        </h3>

                        <p>
                            <strong>Company:</strong>
                            <?php echo htmlspecialchars($internship["company"]); ?>
                        </p>

                        <p>
                            <strong>Duration:</strong>
                            <?php echo htmlspecialchars($internship["duration"]); ?>
                        </p>

                        <p>
                            <strong>Stipend:</strong>
                            <?php echo htmlspecialchars($internship["stipend"]); ?>
                        </p>

                        <p>
                            <strong>Skills:</strong>
                            <?php echo htmlspecialchars($internship["skills"]); ?>
                        </p>

                        <a href="internships.php" class="btn">
                            View Internship
                        </a>

                    </article>

                <?php endforeach; ?>

            </div>

        </div>
    </section>

</main>

<footer class="footer">
    <div class="container">
        <h3 style="color:white;">GreenPath.</h3>
        <p>Learn. Grow. Build your future.</p>
        <p>
            © <?php echo date("Y"); ?> GreenPath Internship Portal
        </p>
    </div>
</footer>

</body>
</html>