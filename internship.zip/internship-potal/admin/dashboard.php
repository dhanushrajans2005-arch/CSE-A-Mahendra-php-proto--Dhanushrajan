<?php
session_start();

if (!isset($_SESSION["admin_logged_in"])) {
    header("Location: login.php");
    exit;
}


$totalStudents = 120;
$totalCompanies = 35;
$totalInternships = 48;
$totalApplications = 96;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard | GreenPath Careers</title>

    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>

<body>

<nav class="navbar">
    <div class="container navbar-inner">

        <a href="dashboard.php" class="logo">
            GreenPath Careers
        </a>

        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="manage_students.php">Students</a>
            <a href="manage_companies.php">Companies</a>
            <a href="manage_internships.php">Internships</a>
            <a href="manage_applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>

    </div>
</nav>

<section>
    <div class="container">

        <p class="eyebrow">Administration Panel</p>

        <h1 class="section-title">
            Welcome, Admin! 🌿
        </h1>

        <p class="section-subtitle">
            Manage your internship portal from one place.
        </p>

        <div class="stats-grid">

            <div class="stat-card">
                <p>Total Students</p>
                <div class="stat-number">
                    <?= $totalStudents ?>
                </div>
                <p>Registered students</p>
            </div>

            <div class="stat-card">
                <p>Total Companies</p>
                <div class="stat-number">
                    <?= $totalCompanies ?>
                </div>
                <p>Registered companies</p>
            </div>

            <div class="stat-card">
                <p>Total Internships</p>
                <div class="stat-number">
                    <?= $totalInternships ?>
                </div>
                <p>Available opportunities</p>
            </div>

            <div class="stat-card">
                <p>Total Applications</p>
                <div class="stat-number">
                    <?= $totalApplications ?>
                </div>
                <p>Student applications</p>
            </div>

        </div>

        <section>
            <h2 class="section-title">Management Center</h2>

            <p class="section-subtitle">
                Choose a section to manage portal information.
            </p>

            <div class="card-grid">

                <div class="card">
                    <h3>🎓 Manage Students</h3>
                    <p>View student information and their profiles.</p>
                    <br>
                    <a href="manage_students.php" class="btn">
                        View Students →
                    </a>
                </div>

                <div class="card">
                    <h3>🏢 Manage Companies</h3>
                    <p>View registered companies and their details.</p>
                    <br>
                    <a href="manage_companies.php" class="btn">
                        View Companies →
                    </a>
                </div>

                <div class="card">
                    <h3>💼 Manage Internships</h3>
                    <p>Review internship opportunities posted by companies.</p>
                    <br>
                    <a href="manage_internships.php" class="btn">
                        View Internships →
                    </a>
                </div>

                <div class="card">
                    <h3>📄 Manage Applications</h3>
                    <p>Review student applications and their statuses.</p>
                    <br>
                    <a href="manage_applications.php" class="btn">
                        View Applications →
                    </a>
                </div>

                <div class="card">
                    <h3>🌱 Visit Website</h3>
                    <p>Open the main internship portal homepage.</p>
                    <br>
                    <a href="../index.php" class="btn btn-outline">
                        Visit Website →
                    </a>
                </div>

            </div>
        </section>

    </div>
</section>

<footer class="footer">
    <div class="container">
        <p>© 2026 GreenPath Careers</p>
        <p>Admin Panel · Growing careers, naturally.</p>
    </div>
</footer>

</body>
</html>