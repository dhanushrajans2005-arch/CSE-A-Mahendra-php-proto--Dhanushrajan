<?php
session_start();

if (!isset($_SESSION["admin_logged_in"]) || $_SESSION["admin_logged_in"] !== true) {
    header("Location: login.php");
    exit;
}


$companies = [
    [
        "id" => 1,
        "name" => "GreenTech Solutions",
        "email" => "hr@greentech.example",
        "phone" => "9876543210",
        "website" => "https://example.com",
        "location" => "Chennai",
        "industry" => "Information Technology"
    ],
    [
        "id" => 2,
        "name" => "Bright Future Technologies",
        "email" => "careers@brightfuture.example",
        "phone" => "9876543211",
        "website" => "",
        "location" => "Coimbatore",
        "industry" => "Software Development"
    ],
    [
        "id" => 3,
        "name" => "NatureSoft Pvt Ltd",
        "email" => "jobs@naturesoft.example",
        "phone" => "9876543212",
        "website" => "",
        "location" => "Bengaluru",
        "industry" => "Web Development"
    ]
];

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$search = trim($_GET["search"] ?? "");

if ($search !== "") {
    $companies = array_values(array_filter(
        $companies,
        function ($company) use ($search) {
            return stripos($company["name"], $search) !== false
                || stripos($company["email"], $search) !== false
                || stripos($company["location"], $search) !== false
                || stripos($company["industry"], $search) !== false;
        }
    ));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Companies | GreenPath Careers</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>

<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a href="dashboard.php" class="logo">GreenPath Careers</a>

        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="manage_students.php">Students</a>
            <a href="manage_companies.php">Companies</a>
            <a href="manage_internships.php">Internships</a>
            <a href="manage_applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<section>
    <div class="container">

        <p class="eyebrow">Admin Management</p>
        <h1 class="section-title">Manage Companies 🏢</h1>

        <p class="section-subtitle">
            View and search registered company information.
        </p>

        <div class="card">
            <form method="GET" action="">
                <div class="form-group">
                    <label for="search">Search Companies</label>
                    <input
                        type="search"
                        id="search"
                        name="search"
                        placeholder="Company name, email, location or industry"
                        value="<?= e($search) ?>"
                    >
                </div>

                <button type="submit">Search</button>

                <a href="manage_companies.php" class="btn btn-outline">
                    Clear
                </a>
            </form>
        </div>

        <p style="margin-top:24px;">
            Companies found: <strong><?= count($companies) ?></strong>
        </p>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Company Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Website</th>
                        <th>Location</th>
                        <th>Industry</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (count($companies) > 0): ?>
                        <?php foreach ($companies as $company): ?>
                            <tr>
                                <td><?= e($company["id"]) ?></td>
                                <td><strong><?= e($company["name"]) ?></strong></td>
                                <td><?= e($company["email"]) ?></td>
                                <td><?= e($company["phone"] ?: "Not provided") ?></td>

                                <td>
                                    <?php if ($company["website"] !== ""): ?>
                                        <a href="<?= e($company["website"]) ?>"
                                           target="_blank"
                                           rel="noopener noreferrer">
                                            Visit Website
                                        </a>
                                    <?php else: ?>
                                        Not provided
                                    <?php endif; ?>
                                </td>

                                <td><?= e($company["location"]) ?></td>
                                <td><?= e($company["industry"]) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align:center;">
                                No companies found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <a href="dashboard.php" class="btn btn-outline">
            ← Back to Dashboard
        </a>

    </div>
</section>

<footer class="footer">
    <div class="container">
        <p>© 2026 GreenPath Careers</p>
        <p>Growing careers, naturally.</p>
    </div>
</footer>

</body>
</html>