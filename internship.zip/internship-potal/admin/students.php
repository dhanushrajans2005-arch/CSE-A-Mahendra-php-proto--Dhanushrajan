<?php
session_start();

if (!isset($_SESSION["admin_logged_in"]) || $_SESSION["admin_logged_in"] !== true) {
    header("Location: login.php");
    exit;
}


$students = [
    [
        "id" => 1,
        "name" => "Dhanushrajan S",
        "email" => "dhanushrajans2005@gmail.com",
        "phone" => "9876543210",
        "college" => "Mahendra College of Engineering",
        "course" => "B.E. Computer Science",
        "year" => "3rd Year",
        "skills" => "PHP, HTML, CSS"
    ],
    [
        "id" => 2,
        "name" => "Bharanidharan K",
        "email" => "bharanidharan0403@gmail.com",
        "phone" => "9876543211",
        "college" => "Mahendra College of Engineering",
        "course" => "B.Tech IT",
        "year" => "2nd Year",
        "skills" => "Python, Java"
    ],
    [
        "id" => 3,
        "name" => "Deepak Raj",
        "email" => "deera@gmail.com",
        "phone" => "9876543212",
        "college" => "Mahendra College of Engineering",
        "course" => "B.E. ECE",
        "year" => "4th Year",
        "skills" => "C, JavaScript"
    ]
];

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

// Search by student name, email, or college
$search = trim($_GET["search"] ?? "");

if ($search !== "") {
    $students = array_values(array_filter(
        $students,
        function ($student) use ($search) {
            return stripos($student["name"], $search) !== false
                || stripos($student["email"], $search) !== false
                || stripos($student["college"], $search) !== false;
        }
    ));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students | GreenPath Careers</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>

<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a href="dashboard.php" class="logo">GreenPath Careers</a>

        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="manage_students.php">Students</a>
            <a href="manage_companies.php">Companies</a>
            <a href="manage_internships.php">Internships</a>
            <a href="manage_applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<section>
    <div class="container">

        <p class="eyebrow">Admin Management</p>
        <h1 class="section-title">Manage Students 🎓</h1>
        <p class="section-subtitle">
            Search and view student information.
        </p>

        <div class="card">
            <form method="GET" action="">
                <div class="form-group">
                    <label for="search">Search Students</label>
                    <input
                        type="search"
                        id="search"
                        name="search"
                        placeholder="Enter name, email, or college"
                        value="<?= e($search) ?>"
                    >
                </div>

                <button type="submit">Search</button>
                <a href="manage_students.php" class="btn btn-outline">
                    Clear
                </a>
            </form>
        </div>

        <p style="margin-top:24px;">
            Students found: <strong><?= count($students) ?></strong>
        </p>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Student</th>
                        <th>Contact</th>
                        <th>College & Course</th>
                        <th>Year</th>
                        <th>Skills</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (count($students) > 0): ?>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?= e($student["id"]) ?></td>

                                <td>
                                    <strong><?= e($student["name"]) ?></strong>
                                </td>

                                <td>
                                    <?= e($student["email"]) ?><br>
                                    <?= e($student["phone"]) ?>
                                </td>

                                <td>
                                    <?= e($student["college"]) ?><br>
                                    <?= e($student["course"]) ?>
                                </td>

                                <td><?= e($student["year"]) ?></td>

                                <td><?= e($student["skills"]) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align:center;">
                                No students found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <a href="dashboard.php" class="btn btn-outline">
            ← Back to Dashboard
        </a>

    </div>
</section>

<footer class="footer">
    <div class="container">
        <p>© 2026 GreenPath Careers</p>
        <p>Growing careers, naturally.</p>
    </div>
</footer>

</body>
</html>