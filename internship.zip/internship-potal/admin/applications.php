<?php
session_start();

if (!isset($_SESSION["admin_logged_in"]) || $_SESSION["admin_logged_in"] !== true) {
    header("Location: login.php");
    exit;
}

// Demo application records
$applications = [
    [
        "id" => 1,
        "student" => "Arun Kumar",
        "email" => "arun@example.com",
        "company" => "GreenTech Solutions",
        "internship" => "PHP Web Developer Intern",
        "location" => "Chennai",
        "status" => "Pending",
        "date" => "2026-10-01"
    ],
    [
        "id" => 2,
        "student" => "Priya S",
        "email" => "priya@example.com",
        "company" => "Bright Future Technologies",
        "internship" => "Frontend Developer Intern",
        "location" => "Coimbatore",
        "status" => "Accepted",
        "date" => "2026-10-02"
    ],
    [
        "id" => 3,
        "student" => "Karthik R",
        "email" => "karthik@example.com",
        "company" => "NatureSoft Pvt Ltd",
        "internship" => "Python Developer Intern",
        "location" => "Remote",
        "status" => "Rejected",
        "date" => "2026-10-03"
    ],
    [
        "id" => 4,
        "student" => "Meena P",
        "email" => "meena@example.com",
        "company" => "GreenTech Solutions",
        "internship" => "PHP Web Developer Intern",
        "location" => "Chennai",
        "status" => "Pending",
        "date" => "2026-10-04"
    ]
];

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$search = trim($_GET["search"] ?? "");
$statusFilter = trim($_GET["status"] ?? "");

$validStatuses = ["Pending", "Accepted", "Rejected"];

if (!in_array($statusFilter, $validStatuses, true)) {
    $statusFilter = "";
}

$applications = array_values(array_filter(
    $applications,
    function ($application) use ($search, $statusFilter) {
        $matchesSearch = $search === ""
            || stripos($application["student"], $search) !== false
            || stripos($application["email"], $search) !== false
            || stripos($application["company"], $search) !== false
            || stripos($application["internship"], $search) !== false;

        $matchesStatus = $statusFilter === ""
            || $application["status"] === $statusFilter;

        return $matchesSearch && $matchesStatus;
    }
));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Applications | GreenPath Careers</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>

<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a href="dashboard.php" class="logo">GreenPath Careers</a>

        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="manage_students.php">Students</a>
            <a href="manage_companies.php">Companies</a>
            <a href="manage_internships.php">Internships</a>
            <a href="manage_applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<section>
    <div class="container">

        <p class="eyebrow">Admin Management</p>
        <h1 class="section-title">Manage Applications 📄</h1>

        <p class="section-subtitle">
            View student applications and check their current status.
        </p>

        <div class="card">
            <form method="GET" action="">

                <div class="form-group">
                    <label for="search">Search Applications</label>
                    <input
                        type="search"
                        id="search"
                        name="search"
                        placeholder="Student, email, company or internship"
                        value="<?= e($search) ?>"
                    >
                </div>

                <div class="form-group">
                    <label for="status">Filter by Status</label>
                    <select id="status" name="status">
                        <option value="">All Applications</option>

                        <?php foreach ($validStatuses as $status): ?>
                            <option
                                value="<?= e($status) ?>"
                                <?= $statusFilter === $status ? "selected" : "" ?>
                            >
                                <?= e($status) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <button type="submit">Apply Filters</button>

                <a href="manage_applications.php" class="btn btn-outline">
                    Clear
                </a>
            </form>
        </div>

        <p style="margin-top:24px;">
            Applications found: <strong><?= count($applications) ?></strong>
        </p>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Student</th>
                        <th>Internship</th>
                        <th>Company</th>
                        <th>Location</th>
                        <th>Applied Date</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (count($applications) > 0): ?>
                        <?php foreach ($applications as $application): ?>
                            <?php
                            $statusClass = strtolower($application["status"]);
                            ?>
                            <tr>
                                <td><?= e($application["id"]) ?></td>

                                <td>
                                    <strong><?= e($application["student"]) ?></strong>
                                    <br>
                                    <?= e($application["email"]) ?>
                                </td>

                                <td><?= e($application["internship"]) ?></td>
                                <td><?= e($application["company"]) ?></td>
                                <td><?= e($application["location"]) ?></td>
                                <td><?= e($application["date"]) ?></td>

                                <td>
                                    <span class="status <?= e($statusClass) ?>">
                                        <?= e($application["status"]) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align:center;">
                                No applications found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <a href="dashboard.php" class="btn btn-outline">
            ← Back to Dashboard
        </a>

    </div>
</section>

<footer class="footer">
    <div class="container">
        <p>© 2026 GreenPath Careers</p>
        <p>Growing careers, naturally.</p>
    </div>
</footer>

</body>
</html>