<?php
session_start();
require_once __DIR__ . "/config/database.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirm = $_POST["confirm_password"] ?? "";
    $role = $_POST["role"] ?? "";

    if ($name === "" || $email === "" || $password === "" ||
        $confirm === "" || $role === "") {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Enter a valid email address.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } elseif (!in_array($role, ["student", "company"], true)) {
        $error = "Select Student or Company.";
    } else {
        try {
            $check = $pdo->prepare(
                "SELECT id FROM users WHERE email = ? LIMIT 1"
            );
            $check->execute([$email]);

            if ($check->fetch()) {
                $error = "This email is already registered.";
            } else {
                $hashedPassword = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $insert = $pdo->prepare(
                    "INSERT INTO users (name, email, password, role)
                     VALUES (?, ?, ?, ?)"
                );

                $insert->execute([
                    $name,
                    $email,
                    $hashedPassword,
                    $role
                ]);

                header("Location: login.php?registered=1");
                exit;
            }
        } catch (PDOException $e) {
            error_log("Registration error: " . $e->getMessage());
            $error = "Registration failed. Please check the database setup.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Create Account | GreenPath</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="navbar">
    <div class="container navbar-inner">
        <a href="index.php" class="logo">GreenPath.</a>
        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="login.php">Login</a>
        </nav>
    </div>
</header>

<main class="container">
    <div class="form-container">
        <h2>Create Account</h2>
        <p>Join GreenPath and discover new opportunities.</p>

        <?php if ($error !== ""): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="register.php">
            <div class="form-group">
                <label for="name">Full Name / Company Name</label>
                <input type="text" id="name" name="name"
                    value="<?= htmlspecialchars($_POST["name"] ?? "") ?>"
                    required>
            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email"
                    value="<?= htmlspecialchars($_POST["email"] ?? "") ?>"
                    required>
            </div>

            <div class="form-group">
                <label for="role">Register As</label>
                <select id="role" name="role" required>
                    <option value="">Choose account type</option>
                    <option value="student">Student</option>
                    <option value="company">Company</option>
                </select>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password"
                    minlength="8" required>
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" id="confirm_password"
                    name="confirm_password" minlength="8" required>
            </div>

            <button type="submit" style="width:100%">
                Create My Account
            </button>
        </form>

        <p style="text-align:center;margin-top:20px">
            Already registered?
            <a href="login.php"><strong>Login here</strong></a>
        </p>
    </div>
</main>

<footer class="footer">
    <div class="container">
        <p>© <?= date("Y") ?> GreenPath Internship Portal</p>
    </div>
</footer>

</body>
</html>