<?php
session_start();

require_once __DIR__ . "/config/database.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $role = trim($_POST["role"] ?? "");

    if ($email === "" || $password === "" || $role === "") {
        $error = "Please fill in all fields.";
    } else {
        try {
            $stmt = $pdo->prepare(
                "SELECT id, name, email, password, role
                 FROM users
                 WHERE email = :email
                 LIMIT 1"
            );

            $stmt->execute([
                "email" => $email
            ]);

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (
                $user &&
                password_verify($password, $user["password"]) &&
                strtolower($user["role"]) === strtolower($role)
            ) {
                session_regenerate_id(true);

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["user_name"] = $user["name"];
                $_SESSION["user_email"] = $user["email"];
                $_SESSION["role"] = strtolower($user["role"]);

                if ($role === "student") {
                    header("Location: student/dashboard.php");
                    exit;
                }

                if ($role === "company") {
                    header("Location: company/dashboard.php");
                    exit;
                }

                if ($role === "admin") {
                    $_SESSION["admin_logged_in"] = true;
                    header("Location: admin/dashboard.php");
                    exit;
                }

            } else {
                $error = "Invalid email, password, or selected role.";
            }

        } catch (PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            $error = "Unable to login. Please check the database connection.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Login | GreenPath</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<header class="navbar">
    <div class="container navbar-inner">

        <a href="index.php" class="logo">GreenPath.</a>

        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="register.php">Create Account</a>
        </nav>

    </div>
</header>

<main class="container">

    <div class="form-container">

        <p class="eyebrow" style="text-align:center;">
            WELCOME BACK
        </p>

        <h2>Login to GreenPath</h2>

        <p style="text-align:center;color:#68786d;margin-bottom:25px;">
            Continue your journey towards a brighter career.
        </p>

        <?php if ($error !== ""): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php">

            <div class="form-group">
                <label for="email">Email Address</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your email"
                    value="<?php echo htmlspecialchars($_POST["email"] ?? ""); ?>"
                    autocomplete="username"
                    required
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                    autocomplete="current-password"
                    required
                >
            </div>

            <div class="form-group">
                <label for="role">Login As</label>

                <select id="role" name="role" required>
                    <option value="">Choose your role</option>

                    <option value="student"
                        <?php echo (($_POST["role"] ?? "") === "student") ? "selected" : ""; ?>>
                        Student
                    </option>

                    <option value="company"
                        <?php echo (($_POST["role"] ?? "") === "company") ? "selected" : ""; ?>>
                        Company
                    </option>

                    <option value="admin"
                        <?php echo (($_POST["role"] ?? "") === "admin") ? "selected" : ""; ?>>
                        Admin
                    </option>
                </select>
            </div>

            <button type="submit" style="width:100%;">
                Login →
            </button>

        </form>

        <p style="text-align:center;margin-top:22px;">
            Don't have an account?
            <a href="register.php">
                <strong>Create Account</strong>
            </a>
        </p>

        <p style="text-align:center;margin-top:12px;font-size:13px;color:#68786d;">
            Your next opportunity starts with one step.
        </p>

    </div>

</main>

<footer class="footer">
    <div class="container">
        <p>
            © <?php echo date("Y"); ?> GreenPath Internship Portal
        </p>
    </div>
</footer>

</body>
</html>
