<?php

echo "PHP is working<br>";

if (extension_loaded("pdo")) {
    echo "PDO is enabled<br>";
} else {
    echo "PDO is NOT enabled<br>";
}

if (extension_loaded("pdo_mysql")) {
    echo "PDO MySQL is enabled";
} else {
    echo "PDO MySQL is NOT enabled";
}

?>